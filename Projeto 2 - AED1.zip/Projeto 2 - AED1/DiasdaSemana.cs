﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_2___AED1
{
    class DiasdaSemana
    {
        public static string SegundaFeira = "SegundaFeira";
        public static string TercaFeira = "TercaFeira";
        public static string QuartaFeira = "QuartaFeira";
        public static string QuintaFeira = "QuintaFeira";
        public static string SextaFeira = "SextaFeira";
    }
}
