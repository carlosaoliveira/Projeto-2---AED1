﻿
using System;
using System.Collections.Generic;
using System.Text;


namespace Projeto_2___AED1
{
    public class DiaDeAula
    {
        public string Dia { get; set; }
        public IList<HorarioAula> HorariosDoDia { get; set; }
    }
}
