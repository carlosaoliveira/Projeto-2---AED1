﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_2___AED1
{
    public class Aluno
    {
        public string nome { get; set; }
        public string email { get; set; }
    }
}
