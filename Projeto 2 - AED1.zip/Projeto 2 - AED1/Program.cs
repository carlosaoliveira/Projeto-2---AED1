﻿using System.Collections.Generic;

namespace Projeto_2___AED1
{
    public class Program
    {
     public IList<EscolaDanca> EscolaDanca { get; set; }
    }
}

